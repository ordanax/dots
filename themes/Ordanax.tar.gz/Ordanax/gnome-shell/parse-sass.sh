#!/bin/sh

bundle exec sass --update --sourcemap=none .
